#include <cstdlib>
#include <iostream>
#include "testlib.h"

using namespace std;

int main(int argc, char * argv[])
{
    setName("sum and product");
    registerTestlibCmd(argc, argv);

    int ja = ans.readInt();
    int pa = ouf.readInt();

    int jb = ans.readInt();
    int pb = ouf.readInt();

    if (ja != pa || jb != pb)
        quitf(_wa, "mismatch");

    quitf(_ok, "answer is %d %d", ja, jb);
}