#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;

int main() {
    int h;
    scanf("%d", &h);
    assert(1 <= h && h <= 1000);

    int mat[h][h];
    memset(mat, 0, sizeof mat);
    mat[0][0] = 1;
    for (int i = 1; i < h; ++i) {
        mat[i][0] = mat[i-1][0];
        for (int j = 1; j < h; ++j)
            mat[i][j] = mat[i-1][j-1] ^ mat[i-1][j];
    }

    int sum = 0;
    for (int i = 0; i < h; ++i)
        for (int j = 0; j < h; ++j)
            if (mat[i][j])
                sum += 1;
    printf("%d\n", sum);
}
