#include "testlib.h"

using namespace std;

int main(){
    registerValidation();
    inf.readInt(1, 1000, "h");
    inf.readEoln();
    inf.readEof();
}
