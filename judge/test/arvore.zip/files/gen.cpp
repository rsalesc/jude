#include "testlib.h"
#include <iostream>

using namespace std;

int main(int argc, char * argv[]){
    registerGen(argc, argv, 1);
    int L = atoi(argv[1]);
    int R = atoi(argv[2]);

    cout << rnd.next(L, R) << endl;
}
